/*
 * app.js — wires ChessGame + BoardView + StockfishEngine together.
 *
 * Everything in here treats engine scores as already White-relative
 * (engine.js did that conversion). This file never looks at whose turn
 * it is to decide the SIGN of a score — only to decide things like
 * mate direction wording ("White mates in 3" vs "Black mates in 3"),
 * which is a presentation question, not a sign-correction question.
 */

const game = new ChessGame();
const engine = new StockfishEngine();

const boardEl = document.getElementById('board');
const filesRowEl = document.getElementById('filesRow');
const evalBarWhite = document.getElementById('evalBarWhite');
const evalBarLabel = document.getElementById('evalBarLabel');
const linesList = document.getElementById('linesList');
const depthValue = document.getElementById('depthValue');
const nodesValue = document.getElementById('nodesValue');
const npsValue = document.getElementById('npsValue');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const moveLog = document.getElementById('moveLog');
const fenInput = document.getElementById('fenInput');
const multipvSelect = document.getElementById('multipvSelect');
const depthSelect = document.getElementById('depthSelect');

let latestLinesByMultiPv = {}; // multipv index -> info object, for the current search
let analysisEnabled = false;

const boardView = new BoardView(boardEl, filesRowEl, game, onUserMove);

// ---------- Engine status ----------

engine.onStatusChange = (text) => {
  statusText.textContent = text;
  const failed = /failed/i.test(text);
  statusDot.classList.toggle('status-ok', text === 'Engine loaded');
  statusDot.classList.toggle('status-error', failed);
  if (failed) {
    statusText.innerHTML = text + '<br><small>Local engine files didn\'t load. See README for running Stockfish locally (recommended) instead of relying on a CDN.</small>';
  }
};

// ---------- Engine output -> UI ----------

engine.onInfo = (info) => {
  // info.cp / info.mate are already White-relative (see engine.js)
  latestLinesByMultiPv[info.multipv] = info;
  renderLines();
  renderEvalBar(getPrimaryLine());

  if (info.depth != null) depthValue.textContent = info.depth;
  if (info.nodes != null) nodesValue.textContent = info.nodes.toLocaleString();
  if (info.nps != null) npsValue.textContent = `${Math.round(info.nps / 1000).toLocaleString()} kn/s`;
};

engine.onBestMove = (result) => {
  if (result.best && result.best !== '(none)') {
    const move = uciToMove(result.best);
    boardView.setBestMoveHighlight(move.from, move.to);
    boardView.render();
  }
};

function getPrimaryLine() {
  return latestLinesByMultiPv[1] || Object.values(latestLinesByMultiPv)[0] || null;
}

// ---------- Eval bar ----------
// The bar fills proportionally to a White-relative score. Centipawns are
// squashed through a sigmoid-ish curve so big advantages don't all look
// like 100%/0% immediately — this mirrors how lichess/chess.com bars feel.

function cpToWhiteFraction(cp) {
  // cp is White-relative centipawns. Map roughly [-1000, 1000] -> [0.02, 0.98]
  const clamped = Math.max(-1000, Math.min(1000, cp));
  const k = 0.0042; // curve steepness
  const sigmoid = 1 / (1 + Math.exp(-k * clamped));
  return 0.02 + sigmoid * 0.96;
}

function renderEvalBar(primary) {
  if (!primary) return;

  let fraction = 0.5;
  let label = '0.0';

  if (primary.mate !== null) {
    // primary.mate is White-relative: positive = White mates, negative = Black mates
    fraction = primary.mate > 0 ? 0.98 : 0.02;
    label = `M${Math.abs(primary.mate)}`;
  } else if (primary.cp !== null) {
    fraction = cpToWhiteFraction(primary.cp);
    const pawns = primary.cp / 100;
    label = (pawns > 0 ? '+' : '') + pawns.toFixed(1);
  }

  evalBarWhite.style.height = `${fraction * 100}%`;
  evalBarLabel.textContent = label;
  evalBarLabel.classList.toggle('label-dark', fraction > 0.5);
}

// ---------- Top lines panel ----------

function formatScore(info) {
  if (info.mate !== null) {
    // White-relative mate: positive => White delivers mate
    return info.mate > 0 ? `Mate in ${info.mate}` : `Mate in ${Math.abs(info.mate)} (Black)`;
  }
  const pawns = info.cp / 100;
  return (pawns > 0 ? '+' : '') + pawns.toFixed(2);
}

function pvToReadableMoves(pvUci, startFen) {
  // Replays the PV on a scratch board purely to produce algebraic-ish
  // "from-to" labels for display, without mutating the real game.
  const scratch = new ChessGame();
  scratch.load(startFen);
  const labels = [];
  for (const uciMove of pvUci.slice(0, 6)) {
    const { from, to, promotion } = uciToMove(uciMove);
    const piece = scratch.piece(from);
    if (!piece) break;
    const made = scratch.move({ from, to, promotion });
    if (!made) break;
    const captureMark = made.capture ? 'x' : '-';
    labels.push(`${piece.type === 'p' ? '' : piece.type.toUpperCase()}${from}${captureMark}${to}`);
  }
  return labels.join(' ');
}

function renderLines() {
  const fenAtSearchStart = game.fen();
  const sorted = Object.values(latestLinesByMultiPv).sort((a, b) => a.multipv - b.multipv);

  linesList.innerHTML = '';
  for (const info of sorted) {
    const row = document.createElement('div');
    row.className = 'line-row';

    const scoreEl = document.createElement('div');
    scoreEl.className = 'line-score';
    scoreEl.textContent = formatScore(info);
    scoreEl.classList.toggle('score-positive', (info.cp ?? info.mate) > 0);
    scoreEl.classList.toggle('score-negative', (info.cp ?? info.mate) < 0);

    const moveEl = document.createElement('div');
    moveEl.className = 'line-moves';
    moveEl.textContent = pvToReadableMoves(info.pv, fenAtSearchStart);

    row.appendChild(scoreEl);
    row.appendChild(moveEl);
    linesList.appendChild(row);
  }
}

// ---------- Driving the engine ----------

function requestAnalysis() {
  if (!analysisEnabled) return;
  latestLinesByMultiPv = {};
  const fen = game.fen();
  const sideToMove = fen.split(' ')[1]; // 'w' or 'b' — read directly from FEN, never assumed
  const depth = parseInt(depthSelect.value, 10);
  const multipv = parseInt(multipvSelect.value, 10);
  engine.analyse(fen, sideToMove, { depth, multipv });
}

function onUserMove() {
  logMove();
  fenInput.value = game.fen();
  requestAnalysis();
}

function logMove() {
  const last = game.history[game.history.length - 1];
  if (!last) return;
  const entry = document.createElement('span');
  entry.className = 'move-entry';
  entry.textContent = `${last.from}${last.to}${last.promotion ? '=' + last.promotion : ''}`;
  moveLog.appendChild(entry);
  moveLog.scrollLeft = moveLog.scrollWidth;
}

// ---------- Controls ----------

document.getElementById('goBtn').addEventListener('click', () => {
  analysisEnabled = true;
  requestAnalysis();
});

document.getElementById('stopBtn').addEventListener('click', () => {
  analysisEnabled = false;
  engine.stop();
});

document.getElementById('flipBtn').addEventListener('click', () => boardView.flip());

document.getElementById('resetBtn').addEventListener('click', () => {
  game.load('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  fenInput.value = game.fen();
  moveLog.innerHTML = '';
  boardView.setLastMove(null, null);
  boardView.setBestMoveHighlight(null, null);
  boardView.render();
  latestLinesByMultiPv = {};
  linesList.innerHTML = '';
  if (analysisEnabled) requestAnalysis();
});

document.getElementById('loadFenBtn').addEventListener('click', () => {
  try {
    game.load(fenInput.value.trim());
    boardView.setLastMove(null, null);
    boardView.setBestMoveHighlight(null, null);
    boardView.render();
    latestLinesByMultiPv = {};
    linesList.innerHTML = '';
    if (analysisEnabled) requestAnalysis();
  } catch (err) {
    alert('That FEN could not be parsed: ' + err.message);
  }
});

multipvSelect.addEventListener('change', requestAnalysis);
depthSelect.addEventListener('change', requestAnalysis);

// ---------- Boot ----------

(async function boot() {
  await engine.init();
})();
