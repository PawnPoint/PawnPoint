/*
 * engine.js — Stockfish UCI wrapper
 * -----------------------------------------------------------------------
 * The single most common bug in homemade analysis boards: UCI scores
 * (`score cp <n>` and `score mate <n>`) are ALWAYS relative to the side
 * to move, not relative to White.
 *
 * That means if it's Black to move and Stockfish reports "cp -600",
 * Black is 6 pawns WORSE, which means White is 6 pawns BETTER.
 * If you feed -600 straight into a White-relative eval bar, the bar
 * (and any +/- you print) will be backwards exactly on Black's turns —
 * which matches "white is clearly winning but eval says -6" perfectly.
 *
 * Fix: convert to White-relative once, in one place, right here in the
 * engine layer. Nothing downstream (UI, eval bar, lines list) ever sees
 * a side-relative number again.
 * -----------------------------------------------------------------------
 */

class StockfishEngine {
  constructor() {
    this.worker = null;
    this.isReady = false;
    this.uciOk = false;
    this.onInfo = null;       // callback(infoObject) for each "info" line during search
    this.onBestMove = null;   // callback(bestMoveObject) when search finishes
    this.onStatusChange = null; // callback(string) for loading/ready/error status
    this.pendingMultiPv = 1;
    this.currentSideToMove = 'w'; // tracked so we can flip scores to White-relative
    this._readyResolvers = [];
  }

  /*
   * Loading the engine file itself is the other place these boards break:
   * the npm "stockfish" package ships hash-suffixed filenames per release
   * (e.g. stockfish-17.1-lite-single-XXXXXXX.js), so a hardcoded CDN URL
   * can silently 404 after an upstream release. We try a short list of
   * known-good paths in order and fall back gracefully, surfacing a clear
   * error instead of hanging forever on "Loading engine...".
   */
  static CANDIDATE_SOURCES = [
    'https://cdn.jsdelivr.net/npm/stockfish@17.1.0/src/stockfish-17.1-lite-single.js',
    'https://cdn.jsdelivr.net/npm/stockfish@16.0.0/src/stockfish-nnue-16-single.js',
    'https://unpkg.com/stockfish@16.0.0/src/stockfish-nnue-16-single.js'
  ];

  async init() {
    this._setStatus('Loading engine…');

    for (const src of StockfishEngine.CANDIDATE_SOURCES) {
      try {
        await this._tryLoad(src);
        this._setStatus('Engine loaded');
        return true;
      } catch (err) {
        console.warn(`Engine source failed: ${src}`, err);
      }
    }

    this._setStatus('Engine failed to load — see console / instructions below');
    return false;
  }

  _tryLoad(src) {
    return new Promise((resolve, reject) => {
      let settled = false;
      let worker;

      try {
        worker = new Worker(src);
      } catch (err) {
        reject(err);
        return;
      }

      const timeout = setTimeout(() => {
        if (!settled) {
          settled = true;
          worker.terminate();
          reject(new Error('Timed out waiting for uciok'));
        }
      }, 8000);

      worker.onerror = (e) => {
        if (!settled) {
          settled = true;
          clearTimeout(timeout);
          worker.terminate();
          reject(e.message || e);
        }
      };

      worker.onmessage = (e) => {
        const line = typeof e.data === 'string' ? e.data : '';
        this._handleLine(line);

        if (!settled && line.includes('uciok')) {
          settled = true;
          clearTimeout(timeout);
          this.worker = worker;
          this.worker.onmessage = (ev) => this._handleLine(
            typeof ev.data === 'string' ? ev.data : ''
          );
          this.worker.onerror = (ev) => console.error('Stockfish worker error:', ev);
          // Standard UCI handshake: send "uci", wait for "uciok",
          // then send "isready" and wait for "readyok" before
          // trusting the engine with real commands.
          this._send('isready');
          resolve();
        }
      };

      worker.postMessage('uci');
    });
  }

  _setStatus(text) {
    if (this.onStatusChange) this.onStatusChange(text);
  }

  _send(cmd) {
    if (this.worker) this.worker.postMessage(cmd);
  }

  /*
   * Parses one line of UCI output.
   * Lines we care about:
   *   "readyok"
   *   "info depth 18 seldepth 24 multipv 1 score cp 34 nodes 123456
   *        nps 980000 pv e2e4 e7e5 g1f3 ..."
   *   "info depth 12 multipv 2 score mate 3 pv ..."
   *   "bestmove e2e4 ponder e7e5"
   */
  _handleLine(line) {
    if (!line) return;

    if (line === 'readyok') {
      this.isReady = true;
      return;
    }

    if (line.startsWith('info') && line.includes('score')) {
      const info = this._parseInfoLine(line);
      if (info && this.onInfo) this.onInfo(info);
      return;
    }

    if (line.startsWith('bestmove')) {
      const parts = line.split(' ');
      const best = parts[1];
      const ponder = parts[3] || null;
      if (this.onBestMove) this.onBestMove({ best, ponder });
      return;
    }
  }

  _parseInfoLine(line) {
    const tokens = line.split(' ');
    const info = {
      depth: null,
      seldepth: null,
      multipv: 1,
      cp: null,        // White-relative centipawns (after conversion below)
      mate: null,      // White-relative mate-in-N (after conversion below)
      nodes: null,
      nps: null,
      pv: []
    };

    let rawCp = null;
    let rawMate = null;

    for (let i = 0; i < tokens.length; i++) {
      switch (tokens[i]) {
        case 'depth':
          info.depth = parseInt(tokens[++i], 10);
          break;
        case 'seldepth':
          info.seldepth = parseInt(tokens[++i], 10);
          break;
        case 'multipv':
          info.multipv = parseInt(tokens[++i], 10);
          break;
        case 'nodes':
          info.nodes = parseInt(tokens[++i], 10);
          break;
        case 'nps':
          info.nps = parseInt(tokens[++i], 10);
          break;
        case 'score':
          // next token is either "cp" or "mate"
          if (tokens[i + 1] === 'cp') {
            rawCp = parseInt(tokens[i + 2], 10);
            i += 2;
          } else if (tokens[i + 1] === 'mate') {
            rawMate = parseInt(tokens[i + 2], 10);
            i += 2;
          }
          break;
        case 'pv':
          info.pv = tokens.slice(i + 1);
          i = tokens.length;
          break;
        default:
          break;
      }
    }

    if (rawCp === null && rawMate === null) return null;

    // ---- THE FIX: convert side-relative score to White-relative ----
    // UCI scores are always from the perspective of the side to move.
    // currentSideToMove is set right before we send "go", from the FEN
    // we are analysing. If Black is to move, flip the sign.
    const sign = (this.currentSideToMove === 'w') ? 1 : -1;

    if (rawCp !== null) info.cp = sign * rawCp;
    if (rawMate !== null) info.mate = sign * rawMate;

    return info;
  }

  /*
   * Kick off analysis of a position.
   * sideToMove must be 'w' or 'b' — read it from the FEN's active-color
   * field (the 2nd space-delimited field), not assumed.
   */
  analyse(fen, sideToMove, { depth = 16, multipv = 3 } = {}) {
    this.currentSideToMove = sideToMove;
    this.pendingMultiPv = multipv;

    this._send('stop');
    this._send(`setoption name MultiPV value ${multipv}`);
    this._send('position fen ' + fen);
    this._send(`go depth ${depth}`);
  }

  stop() {
    this._send('stop');
  }

  newGame() {
    this._send('ucinewgame');
    this._send('isready');
  }
}
