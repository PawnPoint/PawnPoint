# Chess analysis board (Stockfish + eval bar + top lines)

A self-contained analysis board: click-to-move chessboard, a vertical eval
bar, and a top-lines panel (multipv), driven by Stockfish via the UCI
protocol in a Web Worker.

## Files

| File | What it does |
|---|---|
| `index.html` | Page layout: board, eval bar, side panel, move log |
| `chess.js` | Self-contained chess rules engine (legal moves, FEN, check/mate). No dependency on an external chess.js version. |
| `engine.js` | Stockfish Web Worker wrapper. UCI handshake, `info` line parsing, **the White-relative score conversion**. |
| `board.js` | Renders the 8x8 grid from `ChessGame` state, click-to-move interaction. |
| `app.js` | Wires it all together: eval bar fill %, top-lines list, controls. |
| `styles.css` | All styling. |

## Running it

Because of browser security rules around Web Workers and `file://` origins,
**don't just double-click `index.html`**. Serve the folder over local HTTP:

```bash
cd chess-analyzer
python3 -m http.server 8000
# then open http://localhost:8000
```

or `npx serve .` if you have Node installed.

## The bug you were hitting, explained

UCI's `info ... score cp <n>` and `score mate <n>` are **relative to the
side to move**, not relative to White. So:

- White to move, `cp 600` → White is +6.00. Correct as-is.
- **Black to move, `cp -600` → Black is -6.00, which means White is +6.00.**

If your code reads `cp` straight off the `info` line and feeds it into an
eval bar that assumes "positive = White is better," the bar (and any
printed `+`/`-` number) will be backwards on every position where it's
Black's turn — which is exactly the "White is clearly winning but it says
-6" symptom you described.

The fix lives in one place: `engine.js`, inside `_parseInfoLine()`:

```js
const sign = (this.currentSideToMove === 'w') ? 1 : -1;
if (rawCp !== null) info.cp = sign * rawCp;
if (rawMate !== null) info.mate = sign * rawMate;
```

`currentSideToMove` is set from the **FEN's own active-color field**
right before `analyse()` sends `go` — never assumed or hardcoded — so it's
always correct even if you jump to an arbitrary FEN.

Everything downstream (`app.js`, the eval bar, the lines panel) only ever
sees the already-converted White-relative number. That's deliberate: do
the perspective math in exactly one place so it can't drift out of sync
with the rest of the UI.

## Other things this build gets right (also common failure points)

1. **UCI handshake order.** Stockfish needs `uci` → wait for `uciok` →
   `isready` → wait for `readyok`, before you can trust `position`/`go`
   commands. Sending `go` before the engine is ready is a common cause of
   "engine never responds."

2. **MultiPV.** To get multiple top lines you must send
   `setoption name MultiPV value N` **before** `go`, and then track each
   `info` line's own `multipv` field separately — lines for multipv 1, 2, 3
   arrive interleaved across iterative-deepening depths, not in a single
   batch.

3. **Mate scores aren't centipawns.** `score mate 3` and `score cp 50000`
   are different fields in the UCI spec — don't try to convert mate-in-N
   into a centipawn number for the eval bar; treat it as its own case
   (this build pins the bar to 98%/2% and labels it `M3`).

4. **Loading the engine file itself.** The npm `stockfish` package ships
   hash-suffixed filenames per release, so a hardcoded CDN URL can quietly
   404 after an upstream version bump. `engine.js` tries a short list of
   known-good source URLs in order and reports a clear status instead of
   hanging forever on "Loading engine…". If all of them fail (e.g. your
   network blocks the CDN), the most reliable fix is to **download the
   engine file yourself** and serve it locally:

   ```bash
   npm install stockfish
   # find the lite-single .js/.wasm pair under node_modules/stockfish/src/
   # copy both into your project folder, then point CANDIDATE_SOURCES
   # at the local filename instead of a CDN URL
   ```

5. **Multi-threaded WASM needs special HTTP headers.** If you ever switch
   to the full multi-threaded Stockfish build, the page must be served
   with `Cross-Origin-Embedder-Policy: require-corp` and
   `Cross-Origin-Opener-Policy: same-origin`, or the worker will fail to
   allocate shared memory. The single-threaded "lite" build used here
   avoids that requirement entirely, which is why it's the default.

## Extending it

- Promotions currently default to queen on click-to-move; add a small
  picker UI if you want under-promotion support from the board itself.
- `pvToReadableMoves()` in `app.js` renders PV moves as `from-to` pairs
  rather than full SAN (e.g. `Nf3` instead of `Ng1-f3`) to keep the move
  generator simple — swap in a SAN formatter if you want standard notation.
- Arrow-drawing for the top line (rather than a square highlight) is a
  natural next step — `board.js`'s `setBestMoveHighlight` is the hook
  point.
