/*
 * chess.js — minimal self-contained chess rules engine
 * -----------------------------------------------------------------------
 * Handles: board representation, FEN import/export, legal move
 * generation (including castling, en passant, promotion), check /
 * checkmate / stalemate detection.
 *
 * This is intentionally dependency-free so the whole analysis board
 * can be read top to bottom with no hidden library behaviour. It is
 * not a full PGN/SAN engine — moves are represented as {from, to, promotion}
 * square objects, which is all the UI and the Stockfish UCI bridge need.
 * -----------------------------------------------------------------------
 */

const FILES = ['a','b','c','d','e','f','g','h'];

function sq(file, rank) { return `${FILES[file]}${rank + 1}`; } // rank 0-7 -> 1-8
function fileOf(square) { return FILES.indexOf(square[0]); }
function rankOf(square) { return parseInt(square[1], 10) - 1; }
function onBoard(f, r) { return f >= 0 && f < 8 && r >= 0 && r < 8; }

const PIECE_FROM_FEN = {
  p: { type: 'p', color: 'b' }, n: { type: 'n', color: 'b' }, b: { type: 'b', color: 'b' },
  r: { type: 'r', color: 'b' }, q: { type: 'q', color: 'b' }, k: { type: 'k', color: 'b' },
  P: { type: 'p', color: 'w' }, N: { type: 'n', color: 'w' }, B: { type: 'b', color: 'w' },
  R: { type: 'r', color: 'w' }, Q: { type: 'q', color: 'w' }, K: { type: 'k', color: 'w' }
};

const FEN_FROM_PIECE = {
  w: { p: 'P', n: 'N', b: 'B', r: 'R', q: 'Q', k: 'K' },
  b: { p: 'p', n: 'n', b: 'b', r: 'r', q: 'q', k: 'k' }
};

class ChessGame {
  constructor(fen) {
    this.load(fen || 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  }

  load(fen) {
    const [boardPart, turn, castling, ep, halfmove, fullmove] = fen.trim().split(/\s+/);
    this.board = {}; // square string -> {type, color}

    const rows = boardPart.split('/');
    for (let r = 0; r < 8; r++) {
      const row = rows[r];
      let file = 0;
      for (const ch of row) {
        if (/\d/.test(ch)) {
          file += parseInt(ch, 10);
        } else {
          const piece = PIECE_FROM_FEN[ch];
          this.board[sq(file, 7 - r)] = { ...piece };
          file += 1;
        }
      }
    }

    this.turn = turn;
    this.castling = {
      K: castling.includes('K'), Q: castling.includes('Q'),
      k: castling.includes('k'), q: castling.includes('q')
    };
    this.epSquare = (ep && ep !== '-') ? ep : null;
    this.halfmove = parseInt(halfmove || '0', 10);
    this.fullmove = parseInt(fullmove || '1', 10);
    this.history = [];
  }

  fen() {
    let rows = [];
    for (let r = 7; r >= 0; r--) {
      let row = '';
      let empty = 0;
      for (let f = 0; f < 8; f++) {
        const piece = this.board[sq(f, r)];
        if (!piece) {
          empty += 1;
        } else {
          if (empty > 0) { row += empty; empty = 0; }
          row += FEN_FROM_PIECE[piece.color][piece.type];
        }
      }
      if (empty > 0) row += empty;
      rows.push(row);
    }
    const boardPart = rows.join('/');
    const castling = `${this.castling.K ? 'K' : ''}${this.castling.Q ? 'Q' : ''}${this.castling.k ? 'k' : ''}${this.castling.q ? 'q' : ''}` || '-';
    const ep = this.epSquare || '-';
    return `${boardPart} ${this.turn} ${castling} ${ep} ${this.halfmove} ${this.fullmove}`;
  }

  piece(square) { return this.board[square] || null; }

  cloneState() {
    return {
      board: { ...this.board },
      turn: this.turn,
      castling: { ...this.castling },
      epSquare: this.epSquare,
      halfmove: this.halfmove,
      fullmove: this.fullmove
    };
  }

  restoreState(state) {
    this.board = { ...state.board };
    this.turn = state.turn;
    this.castling = { ...state.castling };
    this.epSquare = state.epSquare;
    this.halfmove = state.halfmove;
    this.fullmove = state.fullmove;
  }

  findKing(color) {
    for (const s in this.board) {
      const p = this.board[s];
      if (p && p.type === 'k' && p.color === color) return s;
    }
    return null;
  }

  /* Is `color`'s king currently attacked? */
  isInCheck(color) {
    const kingSq = this.findKing(color);
    if (!kingSq) return false;
    return this._isSquareAttacked(kingSq, color === 'w' ? 'b' : 'w');
  }

  _isSquareAttacked(target, byColor) {
    const tf = fileOf(target), tr = rankOf(target);

    // Pawns
    const pawnDir = byColor === 'w' ? -1 : 1; // attacker pawn sits one rank "behind" relative to target
    for (const df of [-1, 1]) {
      const f = tf + df, r = tr + pawnDir;
      if (onBoard(f, r)) {
        const p = this.board[sq(f, r)];
        if (p && p.type === 'p' && p.color === byColor) return true;
      }
    }

    // Knights
    const knightDeltas = [[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]];
    for (const [df, dr] of knightDeltas) {
      const f = tf + df, r = tr + dr;
      if (onBoard(f, r)) {
        const p = this.board[sq(f, r)];
        if (p && p.type === 'n' && p.color === byColor) return true;
      }
    }

    // King
    for (let df = -1; df <= 1; df++) {
      for (let dr = -1; dr <= 1; dr++) {
        if (df === 0 && dr === 0) continue;
        const f = tf + df, r = tr + dr;
        if (onBoard(f, r)) {
          const p = this.board[sq(f, r)];
          if (p && p.type === 'k' && p.color === byColor) return true;
        }
      }
    }

    // Sliding: rook/queen on ranks+files
    const rookDirs = [[1,0],[-1,0],[0,1],[0,-1]];
    for (const [df, dr] of rookDirs) {
      let f = tf + df, r = tr + dr;
      while (onBoard(f, r)) {
        const p = this.board[sq(f, r)];
        if (p) {
          if (p.color === byColor && (p.type === 'r' || p.type === 'q')) return true;
          break;
        }
        f += df; r += dr;
      }
    }

    // Sliding: bishop/queen on diagonals
    const bishopDirs = [[1,1],[1,-1],[-1,1],[-1,-1]];
    for (const [df, dr] of bishopDirs) {
      let f = tf + df, r = tr + dr;
      while (onBoard(f, r)) {
        const p = this.board[sq(f, r)];
        if (p) {
          if (p.color === byColor && (p.type === 'b' || p.type === 'q')) return true;
          break;
        }
        f += df; r += dr;
      }
    }

    return false;
  }

  /* Pseudo-legal moves for the piece on `square` (does not check for self-check) */
  _pseudoMovesFrom(square) {
    const piece = this.board[square];
    if (!piece) return [];
    const f0 = fileOf(square), r0 = rankOf(square);
    const moves = [];
    const addIfOk = (f, r, captureOnly = false, quietOnly = false) => {
      if (!onBoard(f, r)) return false;
      const target = sq(f, r);
      const occupant = this.board[target];
      if (occupant) {
        if (occupant.color !== piece.color && !quietOnly) moves.push({ to: target, capture: true });
        return false; // blocked either way
      } else if (!captureOnly) {
        moves.push({ to: target, capture: false });
      }
      return !occupant; // can continue sliding if empty
    };

    if (piece.type === 'p') {
      const dir = piece.color === 'w' ? 1 : -1;
      const startRank = piece.color === 'w' ? 1 : 6;
      const promoRank = piece.color === 'w' ? 7 : 0;
      // forward one
      if (onBoard(f0, r0 + dir) && !this.board[sq(f0, r0 + dir)]) {
        moves.push({ to: sq(f0, r0 + dir), capture: false, promotion: (r0 + dir === promoRank) });
        // forward two from start
        if (r0 === startRank && !this.board[sq(f0, r0 + 2 * dir)]) {
          moves.push({ to: sq(f0, r0 + 2 * dir), capture: false, doublePush: true });
        }
      }
      // captures (including en passant)
      for (const df of [-1, 1]) {
        const f = f0 + df, r = r0 + dir;
        if (!onBoard(f, r)) continue;
        const target = sq(f, r);
        const occupant = this.board[target];
        if (occupant && occupant.color !== piece.color) {
          moves.push({ to: target, capture: true, promotion: (r === promoRank) });
        } else if (!occupant && target === this.epSquare) {
          moves.push({ to: target, capture: true, enPassant: true });
        }
      }
      return moves;
    }

    if (piece.type === 'n') {
      const deltas = [[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]];
      for (const [df, dr] of deltas) addIfOk(f0 + df, r0 + dr);
      return moves;
    }

    if (piece.type === 'k') {
      for (let df = -1; df <= 1; df++) {
        for (let dr = -1; dr <= 1; dr++) {
          if (df === 0 && dr === 0) continue;
          addIfOk(f0 + df, r0 + dr);
        }
      }
      // Castling
      const rank = piece.color === 'w' ? 0 : 7;
      if (r0 === rank && f0 === 4) {
        const kingSide = piece.color === 'w' ? this.castling.K : this.castling.k;
        const queenSide = piece.color === 'w' ? this.castling.Q : this.castling.q;
        if (kingSide && !this.board[sq(5, rank)] && !this.board[sq(6, rank)]) {
          if (!this._isSquareAttacked(sq(4, rank), piece.color === 'w' ? 'b' : 'w') &&
              !this._isSquareAttacked(sq(5, rank), piece.color === 'w' ? 'b' : 'w') &&
              !this._isSquareAttacked(sq(6, rank), piece.color === 'w' ? 'b' : 'w')) {
            moves.push({ to: sq(6, rank), capture: false, castle: 'king' });
          }
        }
        if (queenSide && !this.board[sq(3, rank)] && !this.board[sq(2, rank)] && !this.board[sq(1, rank)]) {
          if (!this._isSquareAttacked(sq(4, rank), piece.color === 'w' ? 'b' : 'w') &&
              !this._isSquareAttacked(sq(3, rank), piece.color === 'w' ? 'b' : 'w') &&
              !this._isSquareAttacked(sq(2, rank), piece.color === 'w' ? 'b' : 'w')) {
            moves.push({ to: sq(2, rank), capture: false, castle: 'queen' });
          }
        }
      }
      return moves;
    }

    // Sliding pieces: bishop, rook, queen
    const dirs = piece.type === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]]
              : piece.type === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]]
              : [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
    for (const [df, dr] of dirs) {
      let f = f0 + df, r = r0 + dr;
      while (addIfOk(f, r)) { f += df; r += dr; }
    }
    return moves;
  }

  /* Apply a move object {from, to, promotion?} to internal state. No legality check. */
  _applyMove(move) {
    const piece = this.board[move.from];
    const color = piece.color;
    const capturedPiece = this.board[move.to];

    // En passant capture removes a pawn NOT on the destination square
    if (move.enPassant) {
      const capturedRank = rankOf(move.to) + (color === 'w' ? -1 : 1);
      delete this.board[sq(fileOf(move.to), capturedRank)];
    }

    delete this.board[move.from];
    this.board[move.to] = { type: piece.type, color };

    if (move.promotion) {
      this.board[move.to] = { type: move.promotion, color };
    }

    if (move.castle === 'king') {
      const rank = rankOf(move.from);
      delete this.board[sq(7, rank)];
      this.board[sq(5, rank)] = { type: 'r', color };
    } else if (move.castle === 'queen') {
      const rank = rankOf(move.from);
      delete this.board[sq(0, rank)];
      this.board[sq(3, rank)] = { type: 'r', color };
    }

    // Update castling rights
    if (piece.type === 'k') {
      if (color === 'w') { this.castling.K = false; this.castling.Q = false; }
      else { this.castling.k = false; this.castling.q = false; }
    }
    if (piece.type === 'r') {
      if (move.from === 'a1') this.castling.Q = false;
      if (move.from === 'h1') this.castling.K = false;
      if (move.from === 'a8') this.castling.q = false;
      if (move.from === 'h8') this.castling.k = false;
    }
    if (move.to === 'a1') this.castling.Q = false;
    if (move.to === 'h1') this.castling.K = false;
    if (move.to === 'a8') this.castling.q = false;
    if (move.to === 'h8') this.castling.k = false;

    // En passant target square for the *next* move
    this.epSquare = move.doublePush
      ? sq(fileOf(move.from), (rankOf(move.from) + rankOf(move.to)) / 2)
      : null;

    // Halfmove clock (resets on pawn move or capture)
    if (piece.type === 'p' || capturedPiece || move.enPassant) this.halfmove = 0;
    else this.halfmove += 1;

    if (color === 'b') this.fullmove += 1;
    this.turn = color === 'w' ? 'b' : 'w';
  }

  /* All fully legal moves for the side to move, optionally filtered to one square. */
  legalMoves(fromSquare = null) {
    const color = this.turn;
    const squares = fromSquare ? [fromSquare] : Object.keys(this.board);
    const result = [];

    for (const from of squares) {
      const piece = this.board[from];
      if (!piece || piece.color !== color) continue;

      for (const pm of this._pseudoMovesFrom(from)) {
        const candidate = { from, to: pm.to, capture: pm.capture, enPassant: pm.enPassant, castle: pm.castle };

        if (pm.promotion) {
          // Generate one candidate per promotion piece
          for (const promo of ['q', 'r', 'b', 'n']) {
            const withPromo = { ...candidate, promotion: promo };
            if (this._isLegalAfterSimulation(withPromo, color)) result.push(withPromo);
          }
          continue;
        }
        if (pm.doublePush) candidate.doublePush = true;

        if (this._isLegalAfterSimulation(candidate, color)) result.push(candidate);
      }
    }
    return result;
  }

  _isLegalAfterSimulation(move, color) {
    const snapshot = this.cloneState();
    this._applyMove(move);
    const stillInCheck = this.isInCheck(color);
    this.restoreState(snapshot);
    return !stillInCheck;
  }

  /* Public move-maker: pass {from, to, promotion?}. Returns the move made, or null if illegal. */
  move({ from, to, promotion }) {
    const legal = this.legalMoves(from).find(m =>
      m.to === to && (!m.promotion || m.promotion === promotion)
    );
    if (!legal) return null;
    this._applyMove(legal);
    this.history.push({ ...legal, fenAfter: this.fen() });
    return legal;
  }

  inCheck() { return this.isInCheck(this.turn); }
  inCheckmate() { return this.inCheck() && this.legalMoves().length === 0; }
  inStalemate() { return !this.inCheck() && this.legalMoves().length === 0; }
  gameOver() { return this.inCheckmate() || this.inStalemate(); }

  sideToMove() { return this.turn; }
}

// Convert a UCI move string like "e2e4" or "e7e8q" into {from, to, promotion}
function uciToMove(uci) {
  const from = uci.slice(0, 2);
  const to = uci.slice(2, 4);
  const promotion = uci.length > 4 ? uci[4] : undefined;
  return { from, to, promotion };
}
