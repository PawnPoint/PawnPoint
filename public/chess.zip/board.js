/*
 * board.js — renders the 8x8 board from a ChessGame instance and
 * handles click-to-move interaction. Pure DOM, no canvas/SVG library.
 */

const PIECE_GLYPH = {
  w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
  b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' }
};

class BoardView {
  constructor(containerEl, filesRowEl, game, onUserMove) {
    this.container = containerEl;
    this.filesRow = filesRowEl;
    this.game = game;
    this.onUserMove = onUserMove;
    this.flipped = false;
    this.selected = null;
    this.legalTargets = [];
    this.lastMove = null; // {from, to} for highlighting
    this.bestArrow = null; // {from, to} top engine line, drawn as highlight

    this.container.addEventListener('click', (e) => this._handleClick(e));
    this.render();
  }

  flip() {
    this.flipped = !this.flipped;
    this.render();
  }

  setLastMove(from, to) {
    this.lastMove = { from, to };
  }

  setBestMoveHighlight(from, to) {
    this.bestArrow = from && to ? { from, to } : null;
  }

  _squareOrder() {
    const ranks = this.flipped ? [0,1,2,3,4,5,6,7] : [7,6,5,4,3,2,1,0];
    const files = this.flipped ? [7,6,5,4,3,2,1,0] : [0,1,2,3,4,5,6,7];
    return { ranks, files };
  }

  render() {
    this.container.innerHTML = '';
    const { ranks, files } = this._squareOrder();

    for (const r of ranks) {
      for (const f of files) {
        const square = `${'abcdefgh'[f]}${r + 1}`;
        const isLight = (f + r) % 2 === 1;
        const cell = document.createElement('div');
        cell.className = `square ${isLight ? 'light' : 'dark'}`;
        cell.dataset.square = square;

        if (this.selected === square) cell.classList.add('selected');
        if (this.lastMove && (this.lastMove.from === square || this.lastMove.to === square)) {
          cell.classList.add('last-move');
        }
        if (this.bestArrow && (this.bestArrow.from === square || this.bestArrow.to === square)) {
          cell.classList.add('best-move');
        }
        if (this.legalTargets.includes(square)) cell.classList.add('legal-target');

        const piece = this.game.piece(square);
        if (piece) {
          const span = document.createElement('span');
          span.className = `piece piece-${piece.color}`;
          span.textContent = PIECE_GLYPH[piece.color][piece.type];
          cell.appendChild(span);
        }

        this.container.appendChild(cell);
      }
    }

    // file labels under the board, respecting flip
    this.filesRow.innerHTML = '';
    for (const f of files) {
      const label = document.createElement('div');
      label.className = 'file-label';
      label.textContent = 'abcdefgh'[f];
      this.filesRow.appendChild(label);
    }
  }

  _handleClick(e) {
    const cell = e.target.closest('.square');
    if (!cell) return;
    const square = cell.dataset.square;

    if (this.selected) {
      if (this.legalTargets.includes(square)) {
        const piece = this.game.piece(this.selected);
        const isPromotion = piece.type === 'p' &&
          ((piece.color === 'w' && square[1] === '8') || (piece.color === 'b' && square[1] === '1'));

        const move = { from: this.selected, to: square };
        if (isPromotion) move.promotion = 'q'; // default to queen; UI keeps it simple

        const made = this.game.move(move);
        this.selected = null;
        this.legalTargets = [];

        if (made) {
          this.setLastMove(made.from, made.to);
          this.render();
          if (this.onUserMove) this.onUserMove();
          return;
        }
      }
      // clicked elsewhere: reselect or deselect
      this.selected = null;
      this.legalTargets = [];
    }

    const piece = this.game.piece(square);
    if (piece && piece.color === this.game.sideToMove()) {
      this.selected = square;
      this.legalTargets = this.game.legalMoves(square).map(m => m.to);
    }
    this.render();
  }
}
